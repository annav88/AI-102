/*using Azure;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using Microsoft.Extensions.Configuration;

// Get configuration settings from AppSettings
IConfiguration configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .Build();
string endpoint = configuration["DocIntelligenceEndpoint"];
string apiKey = configuration["DocIntelligenceKey"];
AzureKeyCredential credential = new AzureKeyCredential(apiKey);
DocumentAnalysisClient client = new DocumentAnalysisClient(new Uri(endpoint), credential);

string modelId =  configuration["ModelId"];
Uri fileUri = new Uri("https://github.com/MicrosoftLearning/mslearn-ai-document-intelligence/blob/main/Labfiles/02-custom-document-intelligence/test1.jpg?raw=true");
Console.WriteLine($"Analyzing document from Uri: {fileUri.AbsoluteUri}");

AnalyzeDocumentOperation operation = await client.AnalyzeDocumentFromUriAsync(WaitUntil.Completed, modelId, fileUri);
AnalyzeResult result = operation.Value;

Console.WriteLine($"Document was analyzed with model with ID: {result.ModelId}");

foreach (AnalyzedDocument document in result.Documents)
{
    Console.WriteLine($"Document of type: {document.DocumentType}");

    foreach (KeyValuePair<string, DocumentField> fieldKvp in document.Fields)
    {
        string fieldName = fieldKvp.Key;
        DocumentField field = fieldKvp.Value;

        Console.WriteLine($"Field '{fieldName}': ");

        Console.WriteLine($"  Content: '{field.Content}'");
        Console.WriteLine($"  Confidence: '{field.Confidence}'");
    }
}
*/
using Azure;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using System;
using Azure.AI.OpenAI;
using OpenAI.Chat;
using System.ClientModel;
using Microsoft.Extensions.Configuration.Json;
class Program
{
    static async Task Main(string[] args)
    {
        // Load configuration settings from appsettings.json
        IConfiguration configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .Build();

        // Initialize Azure OpenAI settings
        string? oaiEndpoint = configuration["AzureOAIEndpoint"];
        string? oaiKey = configuration["AzureOAIKey"];
        string? oaiDeploymentName = configuration["AzureOAIDeploymentName"];
        HttpClient httpClient = new HttpClient();
        httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {oaiKey}");

        // Initialize Document Intelligence settings
        string docEndpoint = configuration["DocIntelligenceEndpoint"];
        string docApiKey = configuration["DocIntelligenceKey"];
        AzureKeyCredential docCredential = new AzureKeyCredential(docApiKey);
        DocumentAnalysisClient docClient = new DocumentAnalysisClient(new Uri(docEndpoint), docCredential);

        // Main application loop
        do
        {
            Console.WriteLine("Enter your prompt text (or type 'quit' to exit, or 'analyze' to analyze a document):");
            string? inputText = Console.ReadLine();
            if (string.IsNullOrEmpty(inputText)) continue;

            if (inputText.Equals("quit", StringComparison.OrdinalIgnoreCase)) break;

            if (inputText.Equals("analyze", StringComparison.OrdinalIgnoreCase))
            {
                // Perform Document Intelligence analysis
                string modelId = configuration["ModelId"];
                Uri fileUri = new Uri("https://github.com/MicrosoftLearning/mslearn-ai-document-intelligence/blob/main/Labfiles/02-custom-document-intelligence/test1.jpg?raw=true");
                Console.WriteLine($"Analyzing document from Uri: {fileUri.AbsoluteUri}");

                AnalyzeDocumentOperation operation = await docClient.AnalyzeDocumentFromUriAsync(WaitUntil.Completed, modelId, fileUri);
                AnalyzeResult result = operation.Value;

                Console.WriteLine($"Document was analyzed with model ID: {result.ModelId}");

                foreach (AnalyzedDocument document in result.Documents)
                {
                    Console.WriteLine($"Document of type: {document.DocumentType}");

                    foreach (KeyValuePair<string, DocumentField> fieldKvp in document.Fields)
                    {
                        string fieldName = fieldKvp.Key;
                        DocumentField field = fieldKvp.Value;

                        Console.WriteLine($"Field '{fieldName}': Content: '{field.Content}', Confidence: '{field.Confidence}'");
                    }
                }
            }
            else
            {
                 // Configure the Azure OpenAI client
                AzureOpenAIClient azureClient = new (new Uri(oaiEndpoint), new ApiKeyCredential(oaiKey));
                ChatClient chatClient = azureClient.GetChatClient(oaiDeploymentName);

                // Send input text to Azure OpenAI GPT
                Console.WriteLine($"Sending input to Azure OpenAI GPT: {inputText}");
                ChatCompletionOptions chatCompletionsOptions = new ChatCompletionOptions()
                {    
                    MaxOutputTokenCount = 600,    
                    Temperature = 0.9f,
                };
                
                string systemMessage = "You are a helpful assistant";
                ChatCompletion completion = chatClient.CompleteChat(
                        [
                            new SystemChatMessage(systemMessage),
                            new UserChatMessage(inputText)
                        ],
                        chatCompletionsOptions
                    );

                
                Console.WriteLine($"{completion.Role}: {completion.Content[0].Text}");
                                // Perform Document Intelligence analysis
                string modelId = configuration["ModelId"];
                Uri fileUri = new Uri("https://github.com/MicrosoftLearning/mslearn-ai-document-intelligence/blob/main/Labfiles/02-custom-document-intelligence/test1.jpg?raw=true");
                Console.WriteLine($"Analyzing document from Uri: {fileUri.AbsoluteUri}");

                AnalyzeDocumentOperation operation = await docClient.AnalyzeDocumentFromUriAsync(WaitUntil.Completed, modelId, fileUri);
                AnalyzeResult result = operation.Value;

                Console.WriteLine($"Document was analyzed with model ID: {result.ModelId}");

                foreach (AnalyzedDocument document in result.Documents)
                {
                    Console.WriteLine($"Document of type: {document.DocumentType}");

                    foreach (KeyValuePair<string, DocumentField> fieldKvp in document.Fields)
                    {
                        string fieldName = fieldKvp.Key;
                        DocumentField field = fieldKvp.Value;

                        Console.WriteLine($"Field '{fieldName}': Content: '{field.Content}', Confidence: '{field.Confidence}'");
                    }
                }
                /*
                string jsonBody = JsonSerializer.Serialize(requestBody);

                using var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");
                var response = await httpClient.PostAsync($"{oaiEndpoint}/openai/deployments/{oaiDeploymentName}/completions?api-version=2022-12-01", content);

                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Response received from Azure OpenAI GPT: {responseBody}");
                }
                else
                {
                    Console.WriteLine($"Failed to get response from Azure OpenAI GPT: {response.ReasonPhrase}");
                }
                */
            }
        } while (true);
    }
}
