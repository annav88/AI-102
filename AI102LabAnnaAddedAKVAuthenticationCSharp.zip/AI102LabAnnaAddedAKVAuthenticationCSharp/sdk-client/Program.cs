﻿using System;
using Azure;
using Microsoft.Extensions.Configuration;
using System.Text;
using Azure.AI.TextAnalytics;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using System.Net;
using System.Threading.Tasks;

namespace sdk_client
{
    class Program
    {

        //private static string cogSvcEndpoint;
        //private static string cogSvcKey;
        static async Task Main(string[] args)
        {
            try
            {
                // Set console encoding to unicode
                Console.InputEncoding = Encoding.Unicode;
                Console.OutputEncoding = Encoding.Unicode;

                // Get user input (until they enter "quit")
                string userText = "";
                while (userText.ToLower() != "quit")
                {
                    Console.WriteLine("\nEnter some text ('quit' to stop)");
                    userText = Console.ReadLine();
                    if (userText.ToLower() != "quit")
                    {
                        // Call function to detect language
                        string language = await GetLanguage(userText);
                        Console.WriteLine("Language: " + language);
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
//        static string GetLanguage(string text)
        static async Task<string> GetLanguage(string text)
        {
            /*Let's add the AKV client and retrieval of secret from there*/
            var kvUri = $"https://MYAKVStore.vault.azure.net";

            var keyVaultClient = new SecretClient(new Uri(kvUri), new DefaultAzureCredential());
            
            const string keySecretName = "AISecretKey2";
            const string endpointSecretName = "AISecretEndpoint";

            var keySecret = await keyVaultClient.GetSecretAsync(keySecretName);
            var endpointSecret = await keyVaultClient.GetSecretAsync(endpointSecretName);

            // Extract the string values from KeyVaultSecret objects
            string secretKeyValue = keySecret.Value.Value;
            string endpointValue = endpointSecret.Value.Value;

            /*-------------------------------------------------------------*/

            AzureKeyCredential azureKeyCredential = new AzureKeyCredential(secretKeyValue);
            Uri endpoint = new Uri(endpointValue);
            
            // Create client using endpoint and key
                       
            var client = new TextAnalyticsClient(endpoint, azureKeyCredential);
            
            // Call the service to get the detected language
            DetectedLanguage detectedLanguage = await client.DetectLanguageAsync(text);
            return detectedLanguage.Name;
        }
    }
}
